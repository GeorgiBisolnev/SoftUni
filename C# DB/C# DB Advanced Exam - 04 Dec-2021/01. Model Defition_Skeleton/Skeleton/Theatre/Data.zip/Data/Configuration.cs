﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOPPC\DEVSQL;Database=Theatre;Trusted_Connection=True";
    }
}
