﻿

namespace P01_StudentSystem
{
    using System;
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
